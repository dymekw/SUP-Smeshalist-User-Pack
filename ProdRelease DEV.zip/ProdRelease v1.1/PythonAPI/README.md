1. install Python 2.6 or newer
2. install setuptools
3. run:
```
python setup.py build
```
4. run:
```
python setup.py install
```
5. to test application - run: 
```
python Exapmle01
```
